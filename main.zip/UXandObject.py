import tkinter as tk
from tkinter import filedialog, simpledialog
import threading
import pygame
import speech_recognition as sr
import os
import cv2
import face_recognition
from ultralytics import YOLO
import numpy as np
import csv
from datetime import datetime
from PIL import Image, ImageTk

# Global variables
known_face_encodings = []
known_face_names = []
dangerous_objects = ["knife", "gun", "bomb"]
stop_processing_flag = False
video_processing_running = False
recognized_faces = {}
activity_log = []
surveillance_thread = None

# Initialize pygame for sound
pygame.mixer.init()

# Load known faces
def load_known_faces():
    global known_face_encodings, known_face_names
    print("Loading known faces...")
    face_folder = "faces_folder"
    for filename in os.listdir(face_folder):
        if filename.endswith((".jpg", ".png")):
            image_path = os.path.join(face_folder, filename)
            image = face_recognition.load_image_file(image_path)
            encodings = face_recognition.face_encodings(image)
            if encodings:
                encoding = encodings[0]
                known_face_encodings.append(encoding)
                known_face_names.append(filename.split(".")[0])
                print(f"Loaded {filename.split('.')[0]} from {image_path}")
            else:
                print(f"No face found in {image_path}. Skipping.")

# Function to play alert sound
def play_alert_sound():
    pygame.mixer.music.load("alert.mp3")  # Path to the alert sound file
    pygame.mixer.music.play()

# Log recognized faces and objects to CSV
def log_to_csv(filename, data):
    with open(filename, mode="a", newline="") as file:
        writer = csv.writer(file)
        writer.writerow(data)

# Start surveillance
def start_surveillance():
    global stop_processing_flag, surveillance_thread
    stop_processing_flag = False
    print("Surveillance started!")

    surveillance_thread = threading.Thread(target=surveillance_loop)
    surveillance_thread.daemon = True
    surveillance_thread.start()

# Surveillance loop that processes live feed
def surveillance_loop():
    video_capture = cv2.VideoCapture(0)
    if not video_capture.isOpened():
        print("Error: Couldn't open video capture device.")
        return
    
    model = YOLO('yolov5n.pt')  # Use the lightweight YOLO model
    class_names = model.names
    frame_skip = 2  # Process every 2nd frame

    frame_count = 0
    while not stop_processing_flag:
        ret, frame = video_capture.read()
        if not ret:
            print("Failed to grab frame")
            break

        if frame_count % frame_skip == 0:
            process_frame(frame, model, class_names)
        frame_count += 1

        if cv2.waitKey(1) & 0xFF == ord('q'):
            break

    video_capture.release()
    cv2.destroyAllWindows()

# Stop surveillance
def stop_processing():
    global stop_processing_flag
    stop_processing_flag = True
    print("Surveillance stopped!")

    if surveillance_thread is not None:
        surveillance_thread.join()  # Ensure the thread finishes properly
    print("Surveillance thread stopped!")

# Process a single frame for both face recognition and object detection
def process_frame(frame, model, class_names):
    rgb_frame = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)

    # Face Recognition
    face_locations = face_recognition.face_locations(rgb_frame, model="hog")
    face_encodings = face_recognition.face_encodings(rgb_frame, face_locations)

    for (top, right, bottom, left), face_encoding in zip(face_locations, face_encodings):
        matches = face_recognition.compare_faces(known_face_encodings, face_encoding, tolerance=0.6)
        name = "Unknown"

        if True in matches:
            best_match_index = np.argmin(face_recognition.face_distance(known_face_encodings, face_encoding))
            name = known_face_names[best_match_index]
            log_to_csv('recognized_faces.csv', [name, datetime.now().strftime('%Y-%m-%d %H:%M:%S')])
            play_alert_sound()  # Alert sound for recognized face

        cv2.rectangle(frame, (left, top), (right, bottom), (0, 255, 0), 2)
        cv2.putText(frame, name, (left, top - 10), cv2.FONT_HERSHEY_SIMPLEX, 0.8, (255, 0, 0), 2)

    # Object Detection
    results = model.predict(frame, conf=0.5)
    for result in results:
        for box in result.boxes:
            x1, y1, x2, y2 = map(int, box.xyxy[0])
            confidence = round(float(box.conf[0]), 2)
            class_id = int(box.cls[0])
            class_name = class_names[class_id] if class_id < len(class_names) else f"Unknown ({class_id})"

            label = f"{class_name} ({confidence:.2f})"
            cv2.rectangle(frame, (x1, y1), (x2, y2), (0, 255, 0), 2)
            cv2.putText(frame, label, (x1, y1 - 10), cv2.FONT_HERSHEY_SIMPLEX, 0.5, (0, 255, 0), 2)

            if class_name in dangerous_objects:
                cv2.putText(frame, "DANGER!", (x1, y1 - 30), cv2.FONT_HERSHEY_SIMPLEX, 0.8, (0, 0, 255), 2)
                play_alert_sound()
                log_to_csv('recognized_objects.csv', [class_name, datetime.now().strftime('%Y-%m-%d %H:%M:%S')])

    cv2.imshow("Processing", frame)

# Stop video processing
def stop_video_processing():
    global stop_processing_flag
    stop_processing_flag = True

# Process recorded video
# Process recorded video
def process_recorded_video():
    global stop_processing_flag
    stop_processing_flag = False  # Reset stop flag
    video_path = filedialog.askopenfilename(filetypes=[("Video Files", "*.mp4;*.avi")])

    if not video_path:
        print("No video file selected.")
        return

    print(f"Processing video: {video_path}")
    video_capture = cv2.VideoCapture(video_path)
    
    if not video_capture.isOpened():
        print("Error: Couldn't open video file.")
        return

    # Initialize YOLO model for object detection
    model = YOLO('yolov5n.pt')  # Use the lightweight YOLO model
    class_names = model.names

    frame_count = 0
    while video_capture.isOpened() and not stop_processing_flag:
        ret, frame = video_capture.read()
        if not ret:
            print("Failed to grab frame or end of video.")
            break

        # Process every 2nd frame to improve performance
        if frame_count % 2 == 0:
            process_frame(frame, model, class_names)  # Function to handle both face and object recognition

        frame_count += 1
        cv2.waitKey(1)  # Allow OpenCV to process the frame

    video_capture.release()  # Release the video capture object when done
    cv2.destroyAllWindows()  # Close all OpenCV windows

    print("Video processing completed or stopped.")

# Ensure that the stop button works during video processing
def stop_video_processing():
    global stop_processing_flag
    stop_processing_flag = True
    print("Stopping video processing...")

# Add face to system
def add_face():
    name = simpledialog.askstring("Input", "Enter the name of the person:")
    if name:
        file_path = filedialog.askopenfilename(filetypes=[("Image Files", "*.png;*.jpg")])
        if file_path:
            image = face_recognition.load_image_file(file_path)
            encodings = face_recognition.face_encodings(image)
            if encodings:
                encoding = encodings[0]
                known_face_encodings.append(encoding)
                known_face_names.append(name)
                save_path = os.path.join("faces_folder", f"{name}.jpg")
                cv2.imwrite(save_path, cv2.imread(file_path))
                print(f"Added face for {name}!")
                log_to_csv('activity_log.csv', [f"Added face: {name}", datetime.now().strftime('%Y-%m-%d %H:%M:%S')])

# Manage objects
def manage_objects():
    action = simpledialog.askstring("Choose Action", "Do you want to 'add' or 'delete' a dangerous object?")
    if action:
        action = action.lower()
        if action == "add":
            dangerous_object = simpledialog.askstring("Input", "Enter a dangerous object to log (e.g., knife, gun, bomb):")
            if dangerous_object and dangerous_object not in dangerous_objects:
                dangerous_objects.append(dangerous_object)
                log_to_csv('activity_log.csv', [f"Added dangerous object: {dangerous_object}", datetime.now().strftime('%Y-%m-%d %H:%M:%S')])
                print(f"Added dangerous object: {dangerous_object}")
        elif action == "delete":
            dangerous_object = simpledialog.askstring("Input", "Enter the dangerous object to delete:")
            if dangerous_object in dangerous_objects:
                dangerous_objects.remove(dangerous_object)
                log_to_csv('activity_log.csv', [f"Deleted dangerous object: {dangerous_object}", datetime.now().strftime('%Y-%m-%d %H:%M:%S')])
                print(f"Deleted dangerous object: {dangerous_object}")

# View activity log
def view_activity_log():
    log_window = tk.Toplevel()
    log_window.title("Activity Log")
    log_text = tk.Text(log_window, width=80, height=20)
    log_text.pack()

    if os.path.exists('activity_log.csv'):
        with open('activity_log.csv', 'r') as f:
            log_text.insert(tk.END, f.read())

# Speech recognition helper
def listen_for_commands():
    recognizer = sr.Recognizer()
    microphone = sr.Microphone()

    with microphone as source:
        print("Listening for commands...")
        recognizer.adjust_for_ambient_noise(source)
        audio = recognizer.listen(source)

    try:
        command = recognizer.recognize_google(audio)
        print(f"Voice Command: {command}")

        if "start" in command.lower():
            start_surveillance()
        elif "stop" in command.lower():
            stop_processing()
        elif "process recorded video" in command.lower():
            process_recorded_video()
        elif "add face" in command.lower():
            add_face()
        elif "manage" in command.lower():
            manage_objects()
        elif "view activity log" in command.lower():
            view_activity_log()
        else:
            print("Unrecognized command")

    except sr.UnknownValueError:
        print("Sorry, I did not understand the command.")
        listen_for_commands()  # Retry listening if not understood
    except sr.RequestError:
        print("Sorry, there was an error with the speech service.")
        listen_for_commands()  # Retry on error

# Start voice assistant automatically when the program runs
def start_voice_assistant():
    voice_thread = threading.Thread(target=listen_for_commands)
    voice_thread.daemon = True
    voice_thread.start()

# Create GUI
def create_gui():
    root = tk.Tk()
    root.title("Surveillance System")
    root.geometry("800x600")

    # Header with Blinkers logo
    header = tk.Frame(root, bg="white", height=100)
    header.pack(fill=tk.X, side=tk.TOP)

    logo_path = "blinkers_logo.png"  # Path to the Blinkers logo
    logo_image = Image.open(logo_path)
    logo_image = logo_image.resize((80, 80), Image.Resampling.LANCZOS)
    logo_photo = ImageTk.PhotoImage(logo_image)
    logo_label = tk.Label(header, image=logo_photo, bg="white")
    logo_label.image = logo_photo
    logo_label.pack(side=tk.LEFT, padx=10, pady=10)

    header_title = tk.Label(header, text="निरिक्षण", font=("Arial", 24, "bold"), bg="white")
    header_title.pack(anchor="center",pady=10)

    header_title = tk.Label(header, text="Missing person Survillance", font=("Arial", 24, "bold"), bg="white")
    header_title.pack(anchor="center",pady=10)
    
    tk.Button(root, text="Start Surveillance", font=("Arial", 14), command=start_surveillance).pack(pady=10)
    tk.Button(root, text="Stop Surveillance", font=("Arial", 14), command=stop_processing).pack(pady=10)
    tk.Button(root, text="Process Recorded Video", font=("Arial", 14), command=process_recorded_video).pack(pady=10)
    tk.Button(root, text="Add Face", font=("Arial", 14), command=add_face).pack(pady=10)
    tk.Button(root, text="Manage Dangerous Objects", font=("Arial", 14), command=manage_objects).pack(pady=10)
    tk.Button(root, text="View Activity Log", font=("Arial", 14), command=view_activity_log).pack(pady=10)

    # Start voice assistant automatically when the program runs
    start_voice_assistant()

    root.mainloop()

# Start the program
if __name__ == "__main__":
    load_known_faces()
    create_gui()